<?php $__env->startSection('link-css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<article>
    <?php $__env->startComponent('components.panel.login-panel'); ?><?php echo $__env->renderComponent(); ?>
</article>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link-js'); ?>
    
    <script src="<?php echo e(asset('js/firebase-app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/firebase-auth.js')); ?>"></script>
    
    <script src="<?php echo e(asset('js/firebase-conf.js')); ?>"></script>
    <script src="<?php echo e(asset('js/googleLogin.js')); ?>"></script>

    <script src="<?php echo e(asset('js/cliente-login.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.panel.cliente-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ComposturaV2\resources\views/cliente/cliente-login.blade.php ENDPATH**/ ?>