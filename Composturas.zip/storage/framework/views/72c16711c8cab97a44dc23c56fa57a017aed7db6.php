<?php $__env->startSection('link-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin-inicio-style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <article class="h-100" id="home"> 
        <div class="d-flex justify-content-center align-items-center h-100">
            <div>
                <h1>Bienvenido a panel de admin</h1>
                <p class="lead">Esta es la página de inicio de panel de admin, puedes administrar las citas aqui, para
                    ver más cosas, clic el botón debajo para ver la guía.</p>
                <button type="button" class="btn btn-primary" id="botonGuia">Guía de uso ➞</button>
                <hr>
                <div class="container">
                    <div class="row">
                        <div class="col card m-3 bg-warning" style="max-width: 18rem;">
                            <div class="card-header">Citas pendientes</div>
                            <div class="card-body text-center">
                                <p class="fs-1">
                                    <?php
                                        $contarCitas = 0;
                                        foreach ($citas as $cita) {
                                            if(!$cita['TID']) {
                                                $contarCitas++;
                                            }
                                        }
                                        echo $contarCitas;
                                    ?>
                                </p>
                            </div>
                        </div>
                        <div class="col card m-3 bg-success text-white" style="max-width: 18rem;">
                            <div class="card-header">Citas confirmadas</div>
                            <div class="card-body text-center">
                                <p class="fs-1">
                                    <?php
                                        $contarCitas = 0;
                                        foreach ($citas as $cita) {
                                            if($cita['estado'] == 'confirmado') {
                                                $contarCitas++;
                                            }
                                        }
                                        echo $contarCitas;
                                    ?>
                                </p>
                            </div>
                        </div>
                        <div class="col card m-3 bg-primary text-white" style="max-width: 18rem;">
                            <div class="card-header">Total</div>
                            <div class="card-body text-center">
                                <p class="fs-1"><?php echo e(count($citas)); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </article>
    <article id="citas">
        <section>
        <div class="container-fluid mt-5">
            <div class="row">
                <div class="col input-group mb-3">
                    <button type="button" class="buscar-cliente btn btn-outline-secondary">Cliente</button>
                    <input type="text" class="form-control">
                </div>
                <div class="col input-group mb-3">
                    <button type="button" class="buscar-estado btn btn-outline-secondary">Estado</button>
                    <input type="text" class="form-control">
                </div>
            </div>
        </div>
        <table class="table align-middle" id="tablaCitas">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Cliente</th>
                    <th scope="col">Trabajador</th>
                    <th scope="col">Descripción</th>
                    <th scope="col">Estado</th>
                    <th scope="col">Tiempo de visita</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($cita['CID']); ?></td>
                    <td>
                        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($cliente['UID'] == $cita['UID']): ?>
                                <?php echo e($cliente['apellidos']); ?>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                        <?php $__currentLoopData = $trabajadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabajador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($trabajador['TID'] == $cita['TID']): ?>
                                <?php echo e($trabajador['apellidos']); ?>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!$cita['TID']): ?>
                            <a class="btn btn-primary boton-coger" role="button">Coger</a>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($cita['descripcion']); ?></td>
                    <td>
                        <select class="form-select mt-1" aria-label="Default select example">
                            <option selected><?php echo e($cita['estado']); ?></option>
                            <option>solicitado</option>
                            <option>confirmado</option>
                            <option>en proceso</option>
                            <option>terminado</option>
                            <option>recogido</option>
                        </select></td>
                    <td>
                        <?php
                            $fecha = str_replace($cita['tiempo_visita'], " ", "T");
                        ?>
                        <input type="datetime-local" value="<?php echo e($cita['tiempo_visita']); ?>">
                    </td>
                    <td>
                        <button type="button" class="boton-editar btn btn-outline-success">Editar</button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </section>
    </article>
    <article id="trabajadores">
        <section>
            <div class="container-fluid mt-5">
                <div class="row">
                    <div class="col input-group mb-3">
                        <button type="button" class="buscar-trabajador btn btn-outline-secondary">Apellidos</button>
                        <input type="text" class="form-control">
                    </div>
                    <div class="col input-group mb-3">
                        <button type="button" class="buscar-email btn btn-outline-secondary">Email</button>
                        <input type="text" class="form-control">
                    </div>
                </div>
            </div>
            <table id="tablaTrabajadores" class="table align-middle">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Apellidos</th>
                        <th scope="col">Email</th>
                        <th scope="col">Permiso</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $trabajadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabajador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($trabajador['TID']); ?></td>
                        <td><?php echo e($trabajador['nombre']); ?></td>
                        <td><?php echo e($trabajador['apellidos']); ?></td>
                        <td><?php echo e($trabajador['email']); ?></td>
                        <td>
                            <select class="form-select mt-1" aria-label="Default select example">
                                <option selected><?php echo e($trabajador['permiso']); ?></option>
                                <option>desactivado</option>
                                <option>trabajador</option>
                                <option>administrador</option>
                            </select>
                        </td>
                        <td>
                            <button type="button" class="boton-editar btn btn-outline-success">Editar</button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </section>
    </article>
    <article id="clientes">

        <section>
            <div class="container-fluid mt-5">
                <div class="row">
                    <div class="col input-group mb-3">
                        <button type="button" class="buscar-cliente btn btn-outline-secondary">Apellidos</button>
                        <input type="text" class="form-control">
                    </div>
                    <div class="col input-group mb-3">
                        <button type="button" class="buscar-email btn btn-outline-secondary">Email</button>
                        <input type="text" class="form-control">
                    </div>
                </div>
            </div>
            <table id="tablaClientes" class="table align-middle">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Apellidos</th>
                        <th scope="col">Email</th>
                        <th scope="col">Nº Citas</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($cliente['UID']); ?></td>
                        <td><?php echo e($cliente['nombre']); ?></td>
                        <td><?php echo e($cliente['apellidos']); ?></td>
                        <td><?php echo e($cliente['email']); ?></td>
                        <td>
                            <?php
                                $contadorCitas = 0;
                                foreach ($citas as $cita)
                                    if ($cita['UID'] == $cliente['UID'])
                                        $contadorCitas++;
                                echo $contadorCitas;
                            ?>
                        </td>
                        <td>
                            <button type="button" class="boton-ver-citas btn btn-primary">Ver citas</button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
    </article>
    <article class="h-100" id="guia">
            <embed class="w-100 h-100" src="<?php echo e(asset('pdfs/Guía de uso.pdf')); ?>" type="application/pdf"/>
    </article>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('link-js'); ?>
<script src="<?php echo e(asset('js/admin-inicio-navegacion.js')); ?>"></script>
<script src="<?php echo e(asset('js/admin-inicio.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.panel.admin-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ComposturaV2\resources\views/admin/admin-inicio.blade.php ENDPATH**/ ?>