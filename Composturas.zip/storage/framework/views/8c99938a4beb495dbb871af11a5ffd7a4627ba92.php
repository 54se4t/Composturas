<?php $__env->startSection('link-css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <article class="container">
        <div class="row justify-content-center">
            <h2 class="col col-xl-6 ">Mis datos</h2>
        </div>
        <div class="row justify-content-center">
            <div class="col col-xl-6">
                <table class="table">
                    <tbody>
                        <tr>
                            <th scope="row">Nombre</th>
                            <td><?php echo e(Session::get('usuario')['nombre']); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Apellidos</th>
                            <td><?php echo e(Session::get('usuario')['apellidos']); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Email</th>
                            <td><?php echo e(Session::get('usuario')['email']); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col col-xl-6">
                <button type="button" class="btn btn-primary" id="boton-editar">Editar</button>
                <button type="button" class="btn btn-success" id="boton-aceptar" disabled>Aceptar edición</button>
            </div>
        </div>
    </article>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link-js'); ?>
    <script src="<?php echo e(asset('js/cliente-perfil.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.panel.cliente-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ComposturaV2\resources\views/cliente/cliente-perfil.blade.php ENDPATH**/ ?>