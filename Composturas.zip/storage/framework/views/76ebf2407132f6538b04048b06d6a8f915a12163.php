<?php $__env->startSection('link-css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<section>
    <div class="container">
        <div class="row justify-content-center">
            <form class="col-sm-6">

                <h1 class="h3 mb-3 fw-normal">Iniciar sesión</h1>

                <div class="form-floating">
                    <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
                    <label for="floatingInput">Email</label>
                </div>
                <div class="form-floating">
                    <input type="password" class="form-control" id="floatingPassword" placeholder="Password">
                    <label for="floatingPassword">Contraseña</label>
                </div>
                <button class="botonLogin w-100 btn btn-lg btn-primary">Iniciar sesión</button>
                <div class="pb-3 mb-4 border-bottom"></div>
                <button class="w-100 btn btn-lg btn-outline-secondary">
                    <img src="imgs/icons8-logo-de-google.svg" alt="Icono de google">
                    Continual con Google
                </button>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link-js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.panel.cliente-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ComposturaV2\resources\views/cliente-login.blade.php ENDPATH**/ ?>